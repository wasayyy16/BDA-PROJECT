import os
import numpy as np
from pymongo import MongoClient
import librosa
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import soundfile as sf

# Connect to MongoDB
client = MongoClient('localhost', 27017)
db = client['music_db']
collection = db['audio_features']

# Retrieve track IDs and MFCC features from MongoDB
cursor = collection.find({}, {'track_id': 1, 'mfcc': 1})

# Create the output directory if it doesn't exist
output_dir = '/home/hdoop/Downloads/project/audio_tracks/'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Generate HTML content
html_content = """
<!DOCTYPE html>
<html>
<head>
    <title>Reconstructed Audio Tracks</title>
</head>
<body>
    <h1>Reconstructed Audio Tracks</h1>
    <ul>
"""

for document in cursor:
    track_id = document['track_id']
    mfcc_features = np.array(document['mfcc'])
    
    # Inverse standardization
    scaler = StandardScaler()
    mfcc_reduced = scaler.fit_transform(mfcc_features)
    
    # Fit PCA with the reduced MFCC features
    pca = PCA(n_components=10)  # Use the same number of components as in the phase 1 code
    pca.fit(mfcc_reduced)
    
    # Inverse PCA
    mfcc_reconstructed = pca.inverse_transform(mfcc_reduced).T
    
    # Inverse MFCC
    audio_reconstructed = librosa.feature.inverse.mfcc_to_audio(mfcc_reconstructed)
    
    # Save reconstructed audio file
    audio_path = os.path.join(output_dir, f'{track_id}.wav')
    sf.write(audio_path, audio_reconstructed.T, 22050)  # Assuming 22,050 Hz sample rate
    
    # Embed audio player in HTML
    audio_player = f'<audio controls><source src="{audio_path}" type="audio/wav"></audio>'
    
    # Add track to HTML content
    html_content += f'<li>Track ID: {track_id} - {audio_player}</li>'

html_content += """
    </ul>
</body>
</html>
"""

# Save HTML content to a file
output_html = '/home/hdoop/Downloads/project/reconstructed_audio_tracks.html'
with open(output_html, 'w') as f:
    f.write(html_content)

client.close()

