document.addEventListener('DOMContentLoaded', function() {
    var musicList = document.getElementById('musicList');
    var audioPlayer = document.getElementById('audioPlayer');

    fetch('audio/')
        .then(response => response.json())
        .then(data => {
            data.forEach(track => {
                var audioItem = document.createElement('div');
                audioItem.classList.add('audioItem');
                audioItem.textContent = track;

                audioItem.addEventListener('click', function() {
                    audioPlayer.src = '/audio/' + track;
                    audioPlayer.play();
                });

                musicList.appendChild(audioItem);
            });
        })
        .catch(error => {
            console.error('Error fetching audio files:', error);
        });
});

